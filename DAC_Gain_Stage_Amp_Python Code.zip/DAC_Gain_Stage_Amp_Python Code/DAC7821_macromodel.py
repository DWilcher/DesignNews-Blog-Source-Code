import numpy as np

class DAC7821Macromodel:
    def __init__(self, r_ladder=10000.0, r_fb=10000.0):
        self.R = r_ladder
        self.R_fb = r_fb
        self.data_bus = 0x000

    def load_code_12bit(self, binary_string):
        """Parses a 12-digit binary string into the parallel register."""
        self.data_bus = int(binary_string.strip(), 2) & 0xFFF

    def simulate_output(self, v_in, opamp_gain, v_pos_rail=10.0, v_neg_rail=-5.0):
        """
        Solves KCL at the virtual ground node to determine the output,
        incorporating op-amp finite gain and rail saturation limits.
        """
        i_total = v_in / self.R
        
        fraction_out1 = 0.0
        for bit in range(12):
            bit_value = (self.data_bus >> bit) & 1
            fraction_out1 += bit_value * (1 / (2 ** (12 - bit)))
            
        i_out1_ideal = i_total * fraction_out1
        
        v_iout1_real = i_out1_ideal / ((1.0 / self.R_fb) + (opamp_gain / self.R_fb) + (1.0 / self.R))
        v_out_theoretical = -opamp_gain * v_iout1_real
        
        if v_out_theoretical > v_pos_rail:
            v_out_final = v_pos_rail
        elif v_out_theoretical < v_neg_rail:
            v_out_final = v_neg_rail
        else:
            v_out_final = v_out_theoretical
            
        return v_out_final