import numpy as np
import matplotlib.pyplot as plt
import datetime
import os

class DAC7821_3BitPGA:
    def __init__(self, r1_nominal, r2_nominal):
        """
        Initializes the 3-Bit Programmable Gain Amplifier macromodel.
        """
        self.R1 = float(r1_nominal)
        self.R2 = float(r2_nominal)
        self.bit_pattern = "000"
        self.dac_decimal = 0
        
    def set_3bit_code(self, binary_str):
        """
        Maps a 3-bit user string to the corresponding 12-bit native 
        DAC7821 hardware parallel bus pattern.
        """
        self.bit_pattern = binary_str.strip()
        
        # Hardware Mapping Logic
        if self.bit_pattern == "001":
            self.dac_decimal = 2048  # Bit 11 active (MSB)
        elif self.bit_pattern == "010":
            self.dac_decimal = 1024  # Bit 10 active
        elif self.bit_pattern == "100":
            self.dac_decimal = 512   # Bit 9 active
        else:
            self.dac_decimal = 0     # Loop open condition
            
    def calculate_output_peak(self, v_in_pk):
        """
        Calculates the theoretical output voltage peak using the target formula.
        """
        if self.dac_decimal == 0:
            return float('inf')
        
        # Target Formula matching design criteria
        v_out_pk = v_in_pk * (self.R2 / self.R1) * (4096.0 / self.dac_decimal)
        return v_out_pk

    def apply_tl082_clipping(self, waveform):
        """
        Models real-world asymmetric output rail limits for a loaded TL082 
        operating on a dual +/-10VDC supply structure.
        """
        # Ceiling stays close to positive rail drop; floor limits rigidly at -4.92V
        clipped_waveform = np.clip(waveform, -4.92, 8.5)
        return clipped_waveform

# =====================================================================
# INTERACTIVE SIMULATION RUNTIME ENVIRONMENT
# =====================================================================
if __name__ == "__main__":
    print("=================================================================")
    print("  DAC7821 + TL082: 3-Bit Digitally Controlled Gain Stage Simulator")
    print("=================================================================\n")
    
    try:
        # User Input Section
        r1_val = float(input("Enter R1 value in Ohms (e.g., 10000): "))
        r2_val = float(input("Enter R2 value in Ohms (e.g., 22000): "))
        
        v_pp_in = float(input("Enter Input Voltage Vpeak-to-Vpeak (e.g., 0.200): "))
        freq = float(input("Enter Sine Wave Frequency in Hz (e.g., 1000): "))
        
        print("\nAvailable 3-Bit Gain Control Options:")
        print("  '001' -> Enables Bit 11 (Lowest Target Gain Stage)")
        print("  '010' -> Enables Bit 10 (Mid Target Gain Stage)")
        print("  '100' -> Enables Bit 9  (Highest Target Gain Stage)")
        bit_code = input("Enter 3-bit binary data: ")
        
        if bit_code not in ["001", "010", "100"]:
            print("❌ Input Warning: Code '000' or undefined codes cause loop saturation.")
            
        # Convert Vpp input to Vpeak for internal mathematical scaling
        v_pk_in = v_pp_in / 2.0
        
        # Instantiate and evaluate macromodel
        sim_pga = DAC7821_3BitPGA(r1_nominal=r1_val, r2_nominal=r2_val)
        sim_pga.set_3bit_code(bit_code)
        
        v_pk_out_ideal = sim_pga.calculate_output_peak(v_pk_in)
        v_pp_out_ideal = v_pk_out_ideal * 2.0
        
        # Generate waveforms if output loop is active
        is_clipped_msg = "No"
        if v_pk_out_ideal != float('inf'):
            period = 1.0 / freq
            t = np.linspace(0, 3 * period, 1000)
            
            vin_waveform = v_pk_in * np.sin(2 * np.pi * freq * t)
            
            # The behavioral formula acts non-inverting; generate raw wave
            vout_ideal_waveform = v_pk_out_ideal * np.sin(2 * np.pi * freq * t)
            vout_real_waveform = sim_pga.apply_tl082_clipping(vout_ideal_waveform)
            
            # Check if clipping occurred on the array elements
            if not np.array_equal(vout_ideal_waveform, vout_real_waveform):
                is_clipped_msg = "YES - Output exceeds TL082 physical headroom limits!"
        
        # Construct Diagnostic Output Report text
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        output_report = (
            f"==================================================\n"
            f"SIMULATION RUN TIME: {timestamp}\n"
            f"==================================================\n"
            f"🔹 Input Resistor R1          : {sim_pga.R1:,.1f} Ohms\n"
            f"🔹 Feedback Resistor R2       : {sim_pga.R2:,.1f} Ohms\n"
            f"🔹 Ratio Block (R2 / R1)      : {(sim_pga.R2/sim_pga.R1):.4f}\n"
            f"🔹 Signal Input Frequency     : {freq:,.1f} Hz\n"
            f"🔹 Selection Control Word     : {sim_pga.bit_pattern}\n"
            f"🔹 Mapped DAC Decimal Space   : {sim_pga.dac_decimal if sim_pga.dac_decimal > 0 else 'LOOP OPEN'}\n"
            f"--------------------------------------------------\n"
            f"🔸 Input Signal Voltage       : {v_pp_in:.4f} Vpp  ({v_pk_in:.4f} Vpeak)\n"
            f"🔸 Ideal Target Voltage       : {v_pp_out_ideal:.4f} Vpp  ({v_pk_out_ideal:.4f} Vpeak)\n"
            f"⚠️ Hardware Rail Clipping      : {is_clipped_msg}\n"
            f"==================================================\n\n"
        )
        
        # Display to Screen
        print("\n" + output_report)
        
        # Save Text to External File
        txt_filename = "pga_simulation_log.txt"
        with open(txt_filename, "a", encoding="utf-8") as file:
            file.write(output_report)
        print(f"💾 Text results safely appended to: '{txt_filename}'")
        
        # Signal Plotting and Plot Saving Routine
        if v_pk_out_ideal != float('inf'):
            plt.figure(figsize=(10, 6))
            plt.plot(t * 1e3, vin_waveform, label=f"Input Voltage ({v_pp_in:.3f}Vpp)", color='blue', linewidth=1.5)
            
            if is_clipped_msg != "No":
                plt.plot(t * 1e3, vout_ideal_waveform, label="Ideal Mathematical Curve (No Rail Limit)", color='gray', linestyle=':', alpha=0.7)
                plt.plot(t * 1e3, vout_real_waveform, label="Real TL082 Clipped Output", color='red', linewidth=2.0)
            else:
                plt.plot(t * 1e3, vout_real_waveform, label=f"Output Voltage ({v_pp_out_ideal:.3f}Vpp)", color='green', linewidth=2.0, linestyle='--')
                
            plt.title(f"3-Bit Programmable Gain Stage Simulator Output (Code: {sim_pga.bit_pattern})", fontsize=12, fontweight='bold')
            plt.xlabel("Time (milliseconds)", fontsize=10)
            plt.ylabel("Voltage Amplitude (V)", fontsize=10)
            plt.axhline(0, color='black', linewidth=0.8, linestyle=':')
            plt.grid(True, which='both', linestyle='--', alpha=0.5)
            plt.legend(loc="upper right")
            
            # Save the plot image BEFORE running plt.show()
            # (plt.show() clears the active figure buffer, which results in a blank image if called after)
            img_filename = "pga_waveform_plot.png"
            plt.savefig(img_filename, dpi=300, bbox_inches='tight')
            print(f"🖼️  Waveform plot image safely saved as: '{img_filename}'")
            
            print("📊 Displaying wave visualization graph window...")
            plt.show()
            
    except ValueError:
        print("\n❌ Error: Invalid numerical parameter format entered. Please restart simulation.")