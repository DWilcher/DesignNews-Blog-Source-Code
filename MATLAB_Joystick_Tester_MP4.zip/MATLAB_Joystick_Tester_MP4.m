function Joystick_Tester()

    clear a;
    % === Step 1: Connect to Arduino ===
    try
        if evalin('base', 'exist(''a'', ''var'') && isvalid(a)')
            a = evalin('base', 'a');
        else
            a = arduino('COM10', 'Uno');  % ✅ COM port
            assignin('base', 'a', a);
        end
    catch ME
        error("⚠️ Failed to connect to Arduino on COM10.\n%s", ME.message);
    end

    % === Step 2: Define Pins ===
    relayPin = 'D7';
    xPin = 'A1';
    yPin = 'A2';

    configurePin(a, relayPin, 'DigitalOutput');
    configurePin(a, xPin, 'AnalogInput');
    configurePin(a, yPin, 'AnalogInput');

    % === Step 3: Setup UI and Plot ===
    fig = uifigure('Name', 'Joystick Controller', ...
                   'Position', [100 100 500 400]);  % Larger UI

    % Labels for X and Y joystick values
    xLabel = uilabel(fig, 'Position', [30 320 200 30], ...
                     'Text', 'Joystick X: 0', 'FontSize', 16);
    yLabel = uilabel(fig, 'Position', [270 320 200 30], ...
                     'Text', 'Joystick Y: 0', 'FontSize', 16);

    % Stop button
    stopBtn = uibutton(fig, 'Text', 'Stop', ...
        'Position', [200 20 100 30], ...
        'ButtonPushedFcn', @(btn,event) stopLoop());

    % Axes for live plot
    ax = uiaxes(fig, 'Position', [100 80 300 200]);
    ax.XLim = [0 1023];
    ax.YLim = [0 1023];
    ax.Title.String = 'Live Joystick Position';
    ax.XLabel.String = 'X-axis';
    ax.YLabel.String = 'Y-axis';
    joyDot = plot(ax, 0, 0, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');

    % === Step 4: Prepare Logging ===
    logFile = 'joystick_log.csv';
    fid = fopen(logFile, 'w');
    fprintf(fid, 'Timestamp,X_Value,Y_Value\n');  % CSV header

    % === Step 5: Set up video recording ===
    videoFile = 'joystick_video.mp4';
    vWriter = VideoWriter(videoFile, 'MPEG-4');
    vWriter.FrameRate = 10;
    open(vWriter);

    % === Step 6: Create hidden figure for video recording ===
    f2 = figure('Visible', 'off', 'Position', [700 100 500 400]);
    ax2 = axes(f2);
    axis(ax2, [0 1023 0 1023]);
    xlabel(ax2, 'X-axis');
    ylabel(ax2, 'Y-axis');
    title(ax2, 'Joystick Position (Video Frame)');
    hold(ax2, 'on');
    joyDot2 = plot(ax2, 0, 0, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');

    % === Step 7: Start Live Loop ===
    setappdata(fig, 'runLoop', true);

    while isvalid(fig) && getappdata(fig, 'runLoop')
        % Read analog voltages
        vx = readVoltage(a, xPin);
        vy = readVoltage(a, yPin);

        % === Convert to ADC values and correct directions ===
        xVal = 1023 - round(vx / 5 * 1023);  % ✅ Invert X-axis
        yVal = round(vy / 5 * 1023);         % ✅ Natural Y-axis (up is up)

        % Update UI labels
        xLabel.Text = ['Joystick X: ', num2str(xVal)];
        yLabel.Text = ['Joystick Y: ', num2str(yVal)];

        % Update UI dot
        joyDot.XData = xVal;
        joyDot.YData = yVal;

        % Update video plot
        joyDot2.XData = xVal;
        joyDot2.YData = yVal;
        drawnow;

        % Log data
        t = datetime('now');
        fprintf(fid, '%s,%d,%d\n', datestr(t, 'yyyy-mm-dd HH:MM:SS.FFF'), xVal, yVal);

        % Relay logic
        if yVal > 900
            writeDigitalPin(a, relayPin, 1);
        else
            writeDigitalPin(a, relayPin, 0);
        end

        % Record video frame
        videoFrame = getframe(f2);
        writeVideo(vWriter, videoFrame);

        pause(0.1);  % 100 ms delay
    end

    % === Stop Button Callback ===
    function stopLoop()
        setappdata(fig, 'runLoop', false);
        writeDigitalPin(a, relayPin, 0);  % Turn off relay
        fclose(fid);                      % Close CSV file
        close(vWriter);                   % Finalize MP4
        delete(f2);                       % Close video figure
        delete(fig);                      % Close UI
        disp("✅ CSV saved: " + logFile);
        disp("🎥 Video saved: " + videoFile);
    end
end

