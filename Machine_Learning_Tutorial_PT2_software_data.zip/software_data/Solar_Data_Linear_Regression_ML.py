import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt

# Load data
data = pd.read_csv("solar_data.csv")

# **Check the actual column names in your CSV file**
# Print the column names to identify the correct name for the voltage column
print(data.columns)

# Assuming the voltage column is named 'V' based on the DataFrame preview
X = data[["voltage"]]  # Use the correct column name here (e.g., 'V')
y = data["current"]     # Assuming current is in a column named 'I'

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)

# Predict and evaluate
predictions = model.predict(X_test)
mse = mean_squared_error(y_test, predictions)
print(f"Mean Squared Error: {mse}")

# Determine the model's fit quality
if mse == 0:
    print("Perfect fit: The model predictions exactly match the actual values.")
elif mse < 1e-6:
    print("Excellent fit: The model is highly accurate with minimal error.")
elif mse < 1e-3:
    print("Good fit: The model is reliable but has slight deviations.")
elif mse < 0.1:
    print("Moderate fit: The model has noticeable error but is still useful.")
else:
    print("Poor fit: The model predictions significantly deviate from actual values.")

# Plot the actual data and the model's predictions
plt.figure(figsize=(10, 6))

# Sort X_test and corresponding predictions for a clean line plot
sorted_indices = X_test["voltage"].argsort() # Assuming voltage column is named 'V'
X_sorted = X_test.iloc[sorted_indices]
predictions_sorted = predictions[sorted_indices]

# Plot the actual data points
plt.scatter(X_test, y_test, color='blue', label='Actual Data', alpha=0.6)

# Plot the model's predictions as a line
plt.plot(X_sorted, predictions_sorted, color='red', label='Model Predictions', linewidth=2)

# Add labels and title
plt.xlabel('Voltage (V)')
plt.ylabel('Current (A)')
plt.title('Current vs Voltage Model Predictions (Without Noise)')
plt.legend()

# Show the plot
plt.show()