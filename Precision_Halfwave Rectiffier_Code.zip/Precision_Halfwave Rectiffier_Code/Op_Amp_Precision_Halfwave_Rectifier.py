import numpy as np
import matplotlib.pyplot as plt

# -----------------------------------------------------------
# Op-Amp Macro Model with Inverting Gain
# Vo(peak) = (-R2/R1) * Vin(peak)
# -----------------------------------------------------------
class OpAmpMacroModel:
    def __init__(self, R1, R2):
        self.R1 = R1
        self.R2 = R2
        self.gain = -R2 / R1  # Inverting amplifier gain

    def amplify(self, vin):
        return self.gain * vin

    def vo_peak(self, vin_peak):
        return self.gain * vin_peak


# -----------------------------------------------------------
# Smooth Half-Wave Rectifier
# -----------------------------------------------------------
def smooth_rectifier(v, epsilon=1e-4):
    """
    Smooth half-wave rectification:
    Eliminates sharp discontinuities
    """
    return 0.5 * (v + np.sqrt(v**2 + epsilon))


# -----------------------------------------------------------
# Simulation Function
# -----------------------------------------------------------
def simulate(Vin_peak, R1, R2):
    fs = 200_000          # Sampling frequency
    T = 3e-3              # Simulation time window
    t = np.arange(0, T, 1/fs)

    # Input signal (user-defined peak)
    fin = 1000            # 1 kHz signal
    vin = Vin_peak * np.sin(2 * np.pi * fin * t)

    # Instantiate Op-Amp Macro Model
    opamp = OpAmpMacroModel(R1, R2)

    # Amplify signal
    v_amp = opamp.amplify(vin)

    # Compute peak output using equation
    vo_peak = opamp.vo_peak(Vin_peak)

    # Display results
    print("\n--- Circuit Parameters ---")
    print(f"Vin(peak) = {Vin_peak:.3f} V")
    print(f"R1 = {R1:.2f} ohms")
    print(f"R2 = {R2:.2f} ohms")
    print(f"Gain = -R2/R1 = {opamp.gain:.3f}")
    print(f"Vo(peak) = (-R2/R1)*Vin(peak) = {vo_peak:.3f} V")

    # Smooth rectification
    vrect = smooth_rectifier(v_amp)

    # Add DC offset (optional)
    V_offset = 1.0
    vout = vrect + V_offset

    return t, vin, v_amp, vrect, vout


# -----------------------------------------------------------
# Plot Results
# -----------------------------------------------------------
def plot_results(t, vin, v_amp, vrect, vout):
    plt.figure(figsize=(10, 5))

    plt.plot(t * 1000, vin, label="Vin (AC Input)", alpha=0.6)
    plt.plot(t * 1000, v_amp, label="Amplified (Vo = -R2/R1 * Vin)", linestyle=':')
    plt.plot(t * 1000, vrect, label="Smooth Rectified AC", linestyle='--')
    #plt.plot(t * 1000, vout, label="Shifted Output", linewidth=2)

    plt.xlabel("Time (ms)")
    plt.ylabel("Voltage (V)")
    plt.title("Op-Amp Macromodel with User-Defined Electrical Parameters")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()


# -----------------------------------------------------------
# MAIN PROGRAM
# -----------------------------------------------------------
if __name__ == "__main__":
    print("=== Op-Amp Precision Halfwave Rectifier Simulation ===")

    try:
        # User Inputs
        Vin_peak = float(input("Enter Vin(peak) in volts: "))
        R1 = float(input("Enter R1 in ohms: "))
        R2 = float(input("Enter R2 in ohms: "))

        # Run simulation
        t, vin, v_amp, vrect, vout = simulate(Vin_peak, R1, R2)

        # Plot results
        plot_results(t, vin, v_amp, vrect, vout)

    except ValueError:
        print("Error: Please enter valid numeric values.")