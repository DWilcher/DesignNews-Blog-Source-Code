# ============================================================
# PYTHON OP-AMP SIMULATION + CLEAN SINEWAVE PLOTS
# ============================================================

import numpy as np
import matplotlib.pyplot as plt

# ------------------------------------------------------------
# Define Python-based Op-Amp Macro Model (no external imports)
# ------------------------------------------------------------
class OpAmpMacroModel:
    def __init__(self, Rin=2200, Rfb=4700, gain=100000, Vsat=10):
        self.Rin = Rin
        self.Rfb = Rfb
        self.gain = gain
        self.Vsat = Vsat

    def simulate(self, t, vin):
        """
        Simulates an inverting amplifier using nonlinear saturation
        and simplified op-amp dynamics.
        """
        # Ideal inverting gain
        ideal_gain = -(self.Rfb / self.Rin)
        vout_ideal = ideal_gain * vin

        # Apply op-amp open-loop finite gain correction
        vout = vout_ideal / (1 + (1 / self.gain))

        # Soft-limits saturation
        vout = np.tanh(vout / self.Vsat) * self.Vsat

        return vout


# ------------------------------------------------------------
# Generate equal-cycle sine waves
# ------------------------------------------------------------

# Frequency and cycles
freq = 100               # 1 kHz sinewave
cycles = 2                # Force exactly 2 cycles
Fs = 200_000              # High sampling rate for smooth waveforms
T = cycles / freq         # Total simulation time

t = np.linspace(0, T, int(Fs*T))
vin = 1.0 * np.sin(2*np.pi*freq*t)

# ------------------------------------------------------------
# Create op-amp instance
# ------------------------------------------------------------
opamp = OpAmpMacroModel(Rin=2200, Rfb=4000)

# Simulate output
vout = opamp.simulate(t, vin)

# ------------------------------------------------------------
# Plot INPUT and OUTPUT separately (per your request)
# ------------------------------------------------------------

plt.figure(figsize=(12,5))
plt.plot(t, vin)
plt.title("Input Sine Wave — 2 Cycles")
plt.xlabel("Time (s)")
plt.ylabel("Voltage (V)")
plt.grid(True)
plt.show()

plt.figure(figsize=(12,5))
plt.plot(t, vout)
plt.title("Output Sine Wave — 2 Cycles (Op-Amp Macro Model)")
plt.xlabel("Time (s)")
plt.ylabel("Voltage (V)")
plt.grid(True)
plt.show()
